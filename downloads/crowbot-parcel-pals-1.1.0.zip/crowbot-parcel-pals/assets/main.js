import { MODULE_ID, VERSION, BLOCK_SET, PROFILE, MISSIONS, DEFAULT_TUNING, blank, example, parse, evaluate, generate, registerBlocks, toolbox, clone, byteLength, tuning, readProgress, freshProgress, unlocked, ACTION_LABEL, ACTION_ICON, stepWait } from './model.js';
import { Link, connectionKey, errorText } from './device.js';
import { DeliveryRun, CommandGate } from './session.js';
import { renderBoard } from './board.js';
import { keyInput, keyLabel, acceptsInput } from './controls.js';
import { runtimeCommand } from './runtime.js';
const $ = (id) => { const e = document.getElementById(id); if (!e)
    throw new Error('Missing interface element: ' + id); return e; };
const B = window.Blockly;
let sdk = null, context = null, link = null;
let mission = MISSIONS[0], progress = freshProgress(), draft = blank(), assessment = evaluate(draft, mission);
let student = null, sample = null, editorMission = 0, loading = false, protectedDraft = false, progressWritable = true;
let blocksRegistered = false, gateKey = '', runError = '';
let lightCheck = 'idle', practice = false;
let lightReceipt = '', controlHint = '', lastWire = 'No runtime command sent yet.', lastInput = 'No movement requested yet.';
let recentNonces = [];
let screen = 'home', visible = true, hostVisible = true, disposed = false, initialized = false, busy = false, attention = false;
let receipt = null;
let run = null, gate = null, readCandidate = null, lastStateKey = '', provenance = 'local-editor';
let saveTimer = null, saveChain = Promise.resolve(), pulseEpoch = 0, pulseTimer = null, pulseWake = null;
let confirmAnswer = null, focusBefore = null;
const off = [], observers = [];
const keyDraft = (id = mission.id) => `parcel.v1.stage.${id}`;
const listen = (target, name, fn) => { target.addEventListener(name, fn); off.push(() => target.removeEventListener(name, fn)); };
function click(id, fn) { listen($(id), 'click', () => { void Promise.resolve().then(fn).catch(e => failure(id, e)); }); }
function log(text, error = false) { if (disposed)
    return; const el = document.createElement('div'); el.textContent = text; el.className = error ? 'error' : ''; $('logs').append(el); while ($('logs').children.length > 100)
    $('logs').firstElementChild?.remove(); }
function status(text) { if (!disposed)
    $('status').textContent = text; }
function failure(operation, e) { const msg = operation + ': ' + errorText(e); if (screen === 'play')
    runError = msg; console.error(`[${MODULE_ID} ${VERSION}]`, operation, e); log(msg, true); status(msg); if (screen === 'setup')
    $('uploadNotice').textContent = msg; if (screen === 'play')
    $('runStatus').textContent = msg; }
function say(text) { status(text); log(text); }
async function store(key, value) {
    if (!sdk) {
        status('Open this module in iCreator to save your route.');
        return false;
    }
    try {
        if (byteLength(JSON.stringify(value)) > 240 * 1024)
            throw new Error('This backup is too large for project storage. It stays in this window.');
        await sdk.storage.set(key, value);
        return true;
    }
    catch (e) {
        failure('Save ' + key, e);
        $('saveState').textContent = 'Not saved — keep this window open';
        return false;
    }
}
function snapshot() { return student && editorMission === mission.id ? B.serialization.workspaces.save(student) : clone(draft); }
function metadata(reason) { return { workspaceSchemaVersion: 1, blockSetId: BLOCK_SET, blockSetVersion: VERSION, generatorVersion: VERSION, adapterId: 'parcel-crowbot-esp32', adapterVersion: VERSION, expectedFirmwareVersion: null, timestamp: new Date().toISOString(), provenance: reason }; }
async function saveDraft() {
    if (!initialized || protectedDraft || loading)
        return false;
    if (saveTimer) {
        clearTimeout(saveTimer);
        saveTimer = null;
    }
    const saved = snapshot(), id = mission.id;
    draft = clone(saved);
    let ok = false;
    const work = saveChain.then(async () => { ok = await store(keyDraft(id), saved); if (ok) {
        await store(`parcel.v1.meta.${id}`, metadata(provenance));
        if (!disposed && id === mission.id)
            $('saveState').textContent = 'Saved in this project';
    } });
    saveChain = work.catch(e => failure('Draft save', e));
    await work;
    return ok;
}
function scheduleSave() { if (saveTimer)
    clearTimeout(saveTimer); saveTimer = setTimeout(() => void saveDraft(), 450); }
async function backup(reason) {
    const saved = snapshot();
    if (!sdk)
        throw new Error('Project storage is unavailable. Your current blocks were not replaced.');
    if (!await store('parcel.v1.backup', saved))
        throw new Error('Could not back up your current route. Nothing was replaced.');
    await store('parcel.v1.backup.meta', { ...metadata(reason), mission: mission.id });
}
async function ask(title, text, yes = 'Continue') {
    confirmAnswer?.(false);
    focusBefore = document.activeElement;
    $('modalTitle').textContent = title;
    $('modalText').textContent = text;
    $('modalYes').textContent = yes;
    $('modal').classList.remove('hidden');
    return new Promise(resolve => { confirmAnswer = value => { confirmAnswer = null; $('modal').classList.add('hidden'); focusBefore?.focus(); resolve(value); }; $('modalNo').focus(); });
}
function setScreen(next) {
    if (disposed)
        return;
    screen = next;
    document.body.dataset.screen = next;
    ['home', 'brief', 'build', 'setup', 'play', 'result'].forEach(n => $(n + 'Screen').classList.toggle('hidden', n !== next));
    $('footer').classList.toggle('hidden', next === 'play');
    if (next !== 'play' && document.fullscreenElement === $('playScreen'))
        void document.exitFullscreen().catch(e => log('Fullscreen exit: ' + errorText(e)));
    if (next !== 'play')
        window.scrollTo({ top: 0, behavior: 'instant' });
    if (next === 'build')
        requestAnimationFrame(() => resizeEditors());
    if (next !== 'setup')
        practice = false;
    if (next === 'play')
        requestAnimationFrame(() => $('playScreen').focus({ preventScroll: true }));
    update();
}
function activeRun() { return !!run && ['arming', 'ready', 'sending', 'observe'].includes(run.phase); }
function allowedUiChange() { return !busy && !link?.operation && !activeRun() && !gate?.busy; }
function checkNow() {
    const raw = snapshot();
    assessment = evaluate(raw, mission);
    draft = clone(raw);
    if (receipt && receipt.key !== assessment.key) {
        receipt = null;
        lightCheck = 'idle';
        lightReceipt = '';
    }
    $('feedback').textContent = assessment.message;
    $('checkTitle').textContent = assessment.ok ? 'That route works!' : 'One thing to try';
    $('check').closest('.checkBar')?.classList.toggle('good', assessment.ok);
    try {
        $('python').textContent = generate(raw, mission).source;
    }
    catch (e) {
        $('python').textContent = '# ' + errorText(e);
    }
    const t = assessment.program.tuning;
    for (const k of ['speed', 'forwardMs', 'leftMs', 'rightMs'])
        $(k).setAttribute('data-saved', String(t[k]));
    if (!disposed)
        update();
}
function loadWorkspace(raw) {
    loading = true;
    try {
        draft = clone(raw);
        if (student) {
            B.serialization.workspaces.load(raw, student);
            editorMission = mission.id;
        }
    }
    finally {
        loading = false;
    }
    receipt = null;
    lightCheck = 'idle';
    lightReceipt = '';
    protectedDraft = false;
    checkNow();
    fillTuning();
    resizeEditors();
}
function resizeEditors() { if (!student || screen !== 'build')
    return; B.svgResize(student); B.svgResize(sample); }
async function ensureEditors() {
    if (!B?.serialization?.workspaces)
        throw new Error('Bundled Blockly could not load. Use the updated iCreator host and the complete release ZIP.');
    await new Promise(resolve => requestAnimationFrame(() => resolve()));
    if (!student) {
        if (!blocksRegistered) {
            registerBlocks(B);
            blocksRegistered = true;
        }
        student = B.inject($('student'), { toolbox: toolbox(mission), renderer: 'zelos', trashcan: true, sounds: false, media: './assets/vendor/media/', move: { scrollbars: true, drag: true, wheel: true }, zoom: { controls: true, wheel: true, startScale: .86, minScale: .4, maxScale: 1.4 }, grid: { spacing: 24, length: 3, colour: '#c8dccc', snap: true } });
        sample = B.inject($('sample'), { readOnly: true, renderer: 'zelos', sounds: false, media: './assets/vendor/media/', move: { scrollbars: true, drag: true, wheel: true }, zoom: { controls: true, wheel: true, startScale: .73, minScale: .3, maxScale: 1.3 } });
        student.addChangeListener((event) => { if (loading || disposed || event.isUiEvent || editorMission !== mission.id)
            return; provenance = 'local-editor'; $('codeLabel').textContent = 'Generated from your route and wheel settings.'; checkNow(); if (!protectedDraft)
            scheduleSave(); });
        for (const host of [$('student'), $('sample')]) {
            const o = new ResizeObserver(() => resizeEditors());
            o.observe(host);
            observers.push(o);
        }
    }
    if (editorMission !== mission.id) {
        loading = true;
        try {
            student.updateToolbox(toolbox(mission));
            B.serialization.workspaces.load(draft, student);
            B.serialization.workspaces.load(example(mission), sample);
            editorMission = mission.id;
        }
        finally {
            loading = false;
        }
    }
    resizeEditors();
    requestAnimationFrame(() => { if (screen === 'build') {
        sample.zoomToFit();
        student.scrollCenter();
    } });
    checkNow();
}
function paintMission() {
    $('briefSkill').textContent = 'DELIVERY ' + mission.id + ' · ' + mission.skill;
    $('briefTitle').textContent = mission.title;
    $('briefStory').textContent = mission.houses.length === 1 ? `${mission.houses[0].name} is waiting for ${mission.houses[0].parcel}. Can you help Bolt find the way?` : 'Milo and Olive both have a parcel waiting. Find the repeating pattern and visit them in order.';
    $('buildSkill').textContent = mission.skill;
    $('buildTitle').textContent = mission.title;
    $('hintText').textContent = mission.hint;
    renderBoard($('briefBoard'), mission);
    renderBoard($('buildBoard'), mission);
    renderBoard($('setupBoard'), mission);
    fillTuning();
    renderCards();
}
function renderCards() {
    $('missionCards').replaceChildren();
    $('progressText').textContent = `${progress.cleared.filter(Boolean).length} / 3 delivered`;
    for (const m of MISSIONS) {
        const b = document.createElement('button');
        b.className = 'missionCard';
        b.disabled = m.id > unlocked(progress) || !initialized;
        const num = document.createElement('span');
        num.className = 'missionNumber';
        num.textContent = 'DELIVERY 0' + m.id;
        const icon = document.createElement('span');
        icon.className = 'missionEmoji';
        icon.textContent = m.icon;
        const name = document.createElement('b');
        name.textContent = m.title;
        const sub = document.createElement('small');
        sub.textContent = m.skill;
        const state = document.createElement('small');
        state.className = 'missionState';
        state.textContent = progress.cleared[m.id - 1] ? '✓ Delivered · play again' : b.disabled ? '🔒 Finish the previous delivery' : 'Build this route →';
        b.append(num, icon, name, sub, state);
        b.addEventListener('click', () => void selectMission(m.id).catch(e => failure('Choose mission', e)));
        $('missionCards').append(b);
    }
}
async function selectMission(id) {
    if (!allowedUiChange())
        throw new Error('Finish the robot operation first.');
    if (id > unlocked(progress))
        throw new Error('Deliver the previous parcel first.');
    await saveDraft();
    mission = MISSIONS[id - 1];
    progress.selected = id;
    receipt = null;
    lightCheck = 'idle';
    lightReceipt = '';
    run = null;
    readCandidate = null;
    editorMission = 0;
    protectedDraft = false;
    let raw = null;
    if (sdk) {
        try {
            raw = await sdk.storage.get(keyDraft());
        }
        catch (e) {
            protectedDraft = true;
            failure('Load route', e);
        }
    }
    if (raw) {
        try {
            parse(raw);
            draft = clone(raw);
        }
        catch (e) {
            protectedDraft = true;
            draft = blank();
            failure('Saved route left untouched', e);
        }
    }
    else
        draft = blank();
    if (progressWritable)
        await store('parcel.v1.progress', progress);
    paintMission();
    assessment = evaluate(draft, mission);
    setScreen('brief');
}
function matches() { return !!receipt && assessment.ok && receipt.key === assessment.key && receipt.connection === connectionKey(link?.state ?? null); }
function lightVerified() { return lightCheck === 'passed' && matches() && lightReceipt === receipt.key + '|' + receipt.connection; }
function canHardware() { return !!link && visible && !disposed && link.state?.currentDevice?.profileId === PROFILE; }
function update() {
    if (disposed)
        return;
    const current = link?.state?.currentDevice;
    const op = !!link?.operation, sharedBusy = !!link?.state?.activity, move = activeRun();
    $('connection').textContent = current ? `${current.name} · ${sharedBusy ? 'busy' : 'connected'}` : 'Not connected';
    $('connection').classList.toggle('connected', !!current);
    const set = (id, yes) => $(id).toggleAttribute('disabled', !yes);
    set('begin', initialized);
    set('home', initialized && !busy && !op && !move && !gate?.busy);
    set('save', initialized && !!sdk && !busy && !move && !protectedDraft);
    for (const id of ['buildBack', 'setupBack', 'briefBack', 'reset', 'copyExample', 'restoreBackup', 'applyTuning'])
        set(id, !busy && !op && !move && !gate?.busy);
    set('toSetup', assessment.ok && !protectedDraft && !busy && !op);
    set('check', !busy && !op);
    set('connect', !!link && !busy && !op && !current);
    set('disconnect', canHardware() && !busy && !op && !move && !sharedBusy);
    set('upload', canHardware() && assessment.ok && !protectedDraft && !busy && !op && !sharedBusy && !move && !gate?.busy);
    set('cancelUpload', !!link?.job);
    $('cancelUpload').classList.toggle('hidden', !link?.job);
    const uploaded = matches() && canHardware() && !busy && !op && !sharedBusy && !attention && !gate?.busy;
    const ready = uploaded && lightVerified();
    set('lightTest', uploaded && !practice);
    set('lightYes', lightCheck === 'observe' && uploaded);
    set('lightNo', lightCheck === 'observe' && uploaded);
    $('lightResponse').classList.toggle('hidden', lightCheck !== 'observe');
    $('lightTrouble').classList.toggle('hidden', lightCheck !== 'failed');
    $('lightResult').textContent = lightCheck === 'sending' ? 'Sending light check — watch Bolt, no wheels will start.' : lightCheck === 'observe' ? 'The write returned. Did Bolt actually blink twice?' : lightCheck === 'passed' ? '✓ You saw Bolt blink. Ready for short driving commands.' : lightCheck === 'failed' ? 'You reported no light response. Do not start driving; check the uploaded program first.' : 'After upload, click Blink Bolt to check the program before driving.';
    $('lightTest').textContent = lightCheck === 'sending' ? 'Checking…' : '3. Blink Bolt’s light';
    set('practiceOpen', ready && $('floorReady').checked && !activeRun());
    set('practiceClose', !busy && !gate?.busy);
    $('practicePanel').classList.toggle('hidden', !practice);
    set('start', ready && !practice && $('floorReady').checked && $('startReady').checked);
    for (const id of ['testForward', 'testLeft', 'testRight', 'practiceForward', 'practiceLeft', 'practiceRight'])
        set(id, ready && $('floorReady').checked);
    set('practiceStop', canHardware() && !op);
    set('toolStop', canHardware() && !op);
    set('emergencyStop', canHardware() && !op);
    set('read', canHardware() && !op && !busy && !move && !sharedBusy && !gate?.busy);
    $('cancelRead').classList.toggle('hidden', link?.operation !== 'read');
    if (screen === 'setup' && !busy) {
        $('uploadNotice').textContent = attention ? 'Attend to Bolt. Send STOP before starting another run.' : !current ? 'Connect your Crowbot. Your blocks never move it on their own.' : sharedBusy ? 'The shared robot is busy in another operation.' : !assessment.ok ? 'Go back and finish a valid route.' : matches() ? (lightVerified() ? 'You saw the light check. Reset Bolt to START, then enter delivery controls.' : 'Route upload acknowledged. Next: click Blink Bolt’s light, then tell us what you saw.') : 'Upload this route and wheel settings before playing. This replaces the current device program.';
    }
    $('deviceInfo').textContent = link ? `Profile: ${current?.profileId ?? 'none'} · ${link.operation || 'idle'} · module ${MODULE_ID} v${VERSION}` : 'Open this module in iCreator for device operations.';
    $('runtimeWire').textContent = lastWire;
    if (screen === 'play')
        paintRun();
}
function currentTuning() { try {
    const root = snapshot().blocks.blocks.find(b => b.type === 'parcel_program');
    return root?.data ? tuning(JSON.parse(root.data)) : clone(DEFAULT_TUNING);
}
catch {
    return clone(DEFAULT_TUNING);
} }
function fillTuning() { const t = currentTuning(); for (const k of ['speed', 'forwardMs', 'leftMs', 'rightMs'])
    $(k).value = String(t[k]); }
async function applyTuning() {
    if (!allowedUiChange())
        return;
    const t = tuning({ schema: 1, speed: Number($('speed').value), forwardMs: Number($('forwardMs').value), leftMs: Number($('leftMs').value), rightMs: Number($('rightMs').value) });
    if (student)
        student.getTopBlocks(false).find((b) => b.type === 'parcel_program').data = JSON.stringify(t);
    else
        draft.blocks.blocks[0].data = JSON.stringify(t);
    receipt = null;
    lightCheck = 'idle';
    lightReceipt = '';
    $('startReady').checked = false;
    checkNow();
    await saveDraft();
    $('testStatus').textContent = 'New timing saved in your blocks. Upload it, then test again.';
    update();
}
async function upload() {
    if (!link || busy || !assessment.ok)
        return;
    const artifact = generate(snapshot(), mission), expected = connectionKey(link.state);
    receipt = null;
    lightCheck = 'idle';
    lightReceipt = '';
    practice = false;
    busy = true;
    $('uploadProgress').setAttribute('value', '0');
    $('uploadNotice').textContent = 'Sending the exact route and matching blocks. Keep the host open…';
    update();
    try {
        await saveDraft();
        const result = await link.upload(artifact.snapshot, artifact.source, expected, (text, p) => { if (!disposed) {
            $('uploadProgress').setAttribute('value', String(p));
            $('uploadNotice').textContent = text;
        } });
        if (result !== 'device-confirmed')
            throw new Error('The host did not report device confirmation. Upload again explicitly before playing.');
        if (!visible || disposed || expected !== connectionKey(link.state) || artifact.key !== assessment.key)
            throw new Error('The route, connection or visible session changed. A new upload is required.');
        receipt = { key: artifact.key, connection: expected, tag: artifact.tag };
        attention = false;
        $('uploadProgress').setAttribute('value', '100');
        await store(`parcel.v1.upload.${mission.id}`, { ...metadata('uploaded-to-device'), key: artifact.key, tag: artifact.tag, confirmation: result });
        say('The host acknowledged upload. Test the real robot; no movement or position was verified by this app.');
    }
    catch (e) {
        attention = true;
        failure('Upload: device state may be partial', e);
    }
    finally {
        busy = false;
        update();
    }
}
function newGate(expected) {
    if (!link)
        throw new Error('Connect your Crowbot first.');
    gateKey = expected;
    return new CommandGate(async (text) => {
        lastWire = 'Sending ' + text + ' (' + byteLength(text) + ' bytes)…';
        $('runtimeWire').textContent = lastWire;
        try {
            await link.send(text, expected);
            lastWire = 'Write returned: ' + text + ' (' + byteLength(text) + ' bytes). Physical execution is unconfirmed.';
        }
        catch (e) {
            lastWire = 'Not sent / write failed: ' + errorText(e);
            throw e;
        }
        finally {
            if (!disposed) {
                $('runtimeWire').textContent = lastWire;
                if (screen === 'play')
                    paintRun();
            }
        }
    }, () => visible && !disposed && !!link && connectionKey(link.state) === expected);
}
const nonce = () => {
    let value = '';
    do {
        value = Array.from(crypto.getRandomValues(new Uint8Array(3)), n => n.toString(16).padStart(2, '0')).join('');
    } while (recentNonces.includes(value));
    recentNonces.push(value);
    if (recentNonces.length > 128)
        recentNonces.shift();
    return value;
};
async function testLight() {
    if (!matches() || !canHardware() || busy || activeRun() || gate?.busy || practice)
        return;
    const artifact = generate(snapshot(), mission), expected = receipt.connection, key = receipt.key, e = ++pulseEpoch;
    gate = newGate(expected);
    lightCheck = 'sending';
    lightReceipt = '';
    busy = true;
    update();
    try {
        await gate.send(runtimeCommand(artifact.tag, 't', nonce(), 3));
        if (e !== pulseEpoch || !visible || disposed || !matches())
            return;
        await new Promise(resolve => { pulseWake = resolve; pulseTimer = setTimeout(resolve, 1100); });
        if (e === pulseEpoch && visible && !disposed && matches() && receipt?.key === key && receipt?.connection === expected)
            lightCheck = 'observe';
    }
    catch (e) {
        lightCheck = 'failed';
        failure('Light check', e);
    }
    finally {
        if (pulseTimer)
            clearTimeout(pulseTimer);
        pulseTimer = null;
        pulseWake = null;
        busy = false;
        if (lightCheck === 'sending')
            lightCheck = 'idle';
        update();
    }
}
function observeLight(yes) {
    if (lightCheck !== 'observe' || !matches() || busy)
        return;
    lightCheck = yes ? 'passed' : 'failed';
    lightReceipt = yes ? receipt.key + '|' + receipt.connection : '';
    say(yes ? 'You observed the light check. Press an arrow in Practice, or enter the delivery.' : 'You reported no light. A successful upload/write does not prove this program ran. Re-upload, check power/firmware, and retry the light check.');
    update();
}
async function testPulse(action) {
    if (!lightVerified() || !canHardware() || busy || gate?.busy || !$('floorReady').checked)
        throw new Error('Upload these settings and confirm the clear-floor supervision first.');
    const artifact = generate(snapshot(), mission), expected = receipt.connection, e = ++pulseEpoch;
    gate = newGate(expected);
    busy = true;
    $('startReady').checked = false;
    update();
    try {
        const code = ['forward', 'left', 'right'].indexOf(action);
        $('testStatus').textContent = 'Watch Bolt. One bounded test action is being sent…';
        $('practiceStatus').textContent = 'Sending one short ' + action + ' movement…';
        await gate.send(runtimeCommand(artifact.tag, 't', nonce(), code));
        if (e !== pulseEpoch || !visible)
            return;
        await new Promise(resolve => { pulseWake = resolve; pulseTimer = setTimeout(resolve, stepWait(action, artifact.program.tuning)); });
        if (e === pulseEpoch && visible) {
            $('testStatus').textContent = 'Test command sent. Did the real move fit one square / a quarter-turn? Adjust, upload, and test again if needed.';
            $('practiceStatus').textContent = 'Write returned. Observe the real ' + action + ' action. Release the key before another tap; reset Bolt to START before delivery.';
        }
    }
    catch (e) {
        attention = true;
        receipt = null;
        failure('Robot test', e);
    }
    finally {
        if (pulseTimer)
            clearTimeout(pulseTimer);
        pulseTimer = null;
        pulseWake = null;
        busy = false;
        update();
    }
}
async function startRun() {
    if (!lightVerified() || !canHardware() || busy || attention || practice || !$('floorReady').checked || !$('startReady').checked)
        throw new Error('Upload, check the light, and place Bolt at START first.');
    const artifact = generate(snapshot(), mission), expected = receipt.connection;
    busy = true;
    update();
    try {
        await link.current(expected);
        if (!lightVerified() || disposed || !visible)
            throw new Error('The session changed before delivery.');
        runError = '';
        controlHint = '';
        lastInput = 'No movement requested yet. Use the highlighted arrow or Space.';
        gate = newGate(expected);
        run = new DeliveryRun(artifact, gate, () => paintRun(), () => visible && !disposed && matches());
        setScreen('play');
        $('playMission').textContent = 'DELIVERY ' + mission.id + ' · ' + mission.title;
        await run.begin(nonce());
    }
    catch (e) {
        attention = true;
        receipt = null;
        lightCheck = 'idle';
        failure('Start delivery', e);
    }
    finally {
        busy = false;
        update();
    }
}
function paintRun() {
    if (!run || screen !== 'play' || disposed)
        return;
    const i = run.confirmed, p = run.artifact.program, step = p.steps[i], phase = run.phase;
    const previous = i > 0 ? assessment.trace[i - 1] : null, next = assessment.trace[i];
    renderBoard($('playBoard'), mission, { position: previous?.position ?? mission.start, delivered: previous?.delivered ?? 0, ghost: ['sending', 'observe', 'ready'].includes(phase) ? next?.position : undefined });
    $('stepStrip').replaceChildren();
    p.steps.forEach((s, n) => { const el = document.createElement('span'); el.className = 'stepChip' + (n < i ? ' done' : n === i ? ' current' : ''); el.textContent = ACTION_ICON[s.action]; el.title = ACTION_LABEL[s.action]; $('stepStrip').append(el); });
    $('stepNumber').textContent = `STEP ${Math.min(i + 1, p.steps.length)} OF ${p.steps.length}`;
    $('actionIcon').textContent = step ? ACTION_ICON[step.action] : '✓';
    $('actionTitle').textContent = step ? ACTION_LABEL[step.action] : 'All steps observed';
    const action = step?.action, coord = next ? String.fromCharCode(65 + next.position.x) + (next.position.y + 1) : '';
    $('actionText').textContent = action === 'forward' ? `Bolt plans to reach ${coord}. Watch the real wheels, not just the map.` : action === 'left' || action === 'right' ? 'Bolt will turn in place. Check its heading against the dashed arrow.' : action === 'deliver' ? `Help place the parcel at ${mission.houses[next?.delivered ? next.delivered - 1 : 0]?.name ?? 'your friend'}’s house. The robot will flash its delivery signal.` : 'Bolt parks at the end of your route.';
    $('drive').toggleAttribute('disabled', phase !== 'ready' || busy);
    $('drive').textContent = phase === 'sending' ? 'Sending — please wait…' : step ? ACTION_ICON[step.action] + ' ' + ACTION_LABEL[step.action] + ' · ' + keyLabel(step.action) : 'Route ended';
    $('keyHint').textContent = controlHint || (phase === 'ready' ? 'Your turn: press ' + keyLabel(action) + '. This runs the next step you programmed.' : phase === 'observe' ? 'Look at Bolt, then CLICK Yes or No below. Arrow keys and Space do not confirm movement.' : phase === 'sending' ? 'One short action only — held keys and extra taps do not queue moves.' : '');
    $('inputStatus').textContent = lastInput;
    $('wireStatus').textContent = lastWire;
    for (const [id, act] of [['routeForward', 'forward'], ['routeLeft', 'left'], ['routeRight', 'right']]) {
        $(id).toggleAttribute('disabled', phase !== 'ready' || busy);
        $(id).classList.toggle('suggested', phase === 'ready' && action === act);
        $(id).setAttribute('aria-pressed', String(action === act));
    }
    $('routeStop').toggleAttribute('disabled', !canHardware() || !!link?.operation);
    $('returnSetup').classList.toggle('hidden', phase !== 'aborted');
    $('drive').classList.toggle('hidden', phase === 'observe');
    $('observe').classList.toggle('hidden', phase !== 'observe');
    $('observeQuestion').textContent = action === 'deliver' ? 'Did you see the light signal and place the parcel at the house?' : action === 'park' ? 'Are the real wheels stopped and the light off?' : action === 'forward' ? `Did Bolt reach ${coord} and stop?` : 'Did Bolt turn to face the dashed arrow and stop?';
    $('confirmStep').textContent = action === 'deliver' ? 'Parcel delivered — I saw it ✓' : 'Yes, I saw it ✓';
    $('runStatus').textContent = phase === 'arming' ? 'Preparing a fresh route session — no motion yet.' : phase === 'sending' ? 'Command sent or sending. Wait, then check the real robot.' : phase === 'observe' ? 'Your observation is needed. We cannot sense Bolt’s position.' : phase === 'aborted' ? (runError || 'Delivery paused/ended. Attend to Bolt, then return to setup.') : phase === 'done' ? 'Finishing your delivery…' : 'Ready — nothing moves automatically. Press the highlighted arrow, Space, or the big action button.';
}
function blockedInput(text) { controlHint = text; lastInput = text; if (screen === 'play')
    paintRun();
else if (practice)
    $('practiceStatus').textContent = text; }
async function routeInput(input) {
    if (screen !== 'play' || !visible || disposed || !$('modal').classList.contains('hidden') || !$('tools').classList.contains('hidden'))
        return;
    if (input === 'stop') {
        await stopRobot();
        return;
    }
    if (!run)
        return;
    if (run.phase === 'observe') {
        blockedInput('First look at Bolt and click Yes, I saw it or No movement. This key does not confirm a step.');
        return;
    }
    if (run.phase !== 'ready' || busy || gate?.busy) {
        blockedInput('Wait for this action to finish. Extra taps are not queued.');
        return;
    }
    const action = run.artifact.program.steps[run.confirmed]?.action;
    if (!acceptsInput(input, action)) {
        blockedInput('Your program says ' + (action ? ACTION_LABEL[action] : 'finish') + '. Press ' + keyLabel(action) + ' instead. No command was sent for this key.');
        return;
    }
    controlHint = '';
    lastInput = 'Requested: ' + ACTION_LABEL[action];
    try {
        await run.step();
    }
    catch (e) {
        attention = true;
        receipt = null;
        lightCheck = 'idle';
        failure('Drive step', e);
        update();
    }
}
async function drive() { return routeInput('next'); }
function keyboard(e) {
    const input = keyInput(e.key);
    if (!input || e.ctrlKey || e.altKey || e.metaKey || e.isComposing)
        return;
    if (!visible || disposed || !$('modal').classList.contains('hidden') || !$('tools').classList.contains('hidden'))
        return;
    const el = e.target instanceof Element ? e.target : null;
    if (el?.closest('input,textarea,select,[contenteditable="true"],.blocklyWidgetDiv,.blocklyDropDownDiv'))
        return;
    if (screen !== 'play' && !(screen === 'setup' && practice))
        return;
    // Prevent native Space/Enter button activation; held arrows must never create a motor stream.
    e.preventDefault();
    if (e.repeat)
        return;
    if (screen === 'play') {
        void routeInput(input).catch(err => failure('Keyboard', err));
        return;
    }
    if (input === 'stop' || input === 'next') {
        void stopRobot().catch(err => failure('Practice STOP', err));
        return;
    }
    if (input === 'forward' || input === 'left' || input === 'right') {
        if (busy || gate?.busy) {
            blockedInput('Wait for this short movement to finish; held keys never repeat.');
            return;
        }
        void testPulse(input).catch(err => { failure('Practice controls', err); $('practiceStatus').textContent = errorText(err); });
    }
}
async function confirmStep() {
    if (!run)
        return;
    controlHint = '';
    lastInput = 'You confirmed the previous action. Choose the next step.';
    run.confirm();
    if (run.phase !== 'done')
        return;
    busy = true;
    update();
    try {
        const finishedRun = run;
        const stopped = await gate.stop();
        if (!stopped)
            throw new Error('Finish STOP could not be sent. Attend to Bolt before continuing.');
        if (disposed || !visible || run !== finishedRun || finishedRun.phase !== 'done' || !matches())
            throw new Error('The visible delivery session changed before saving. Check Bolt and restart from setup.');
        progress.cleared[mission.id - 1] = true;
        progress.deliveries[mission.id - 1] = mission.houses.length;
        if (progressWritable)
            await store('parcel.v1.progress', progress);
        await store(`parcel.v1.observed.${mission.id}`, { completedAt: new Date().toISOString(), confirmation: 'user-observed', steps: run.confirmed, assisted: progress.assisted[mission.id - 1] });
        $('resultTitle').textContent = mission.houses.length === 1 ? `${mission.houses[0].name}’s parcel is here!` : 'Two friends. Two happy deliveries!';
        $('resultText').textContent = 'You made a plan, programmed real wheels, and checked what happened. That’s a robot engineer’s delivery!';
        $('resultFriends').replaceChildren();
        mission.houses.forEach(h => { const s = document.createElement('div'); s.className = 'friendStamp'; s.textContent = h.emoji; const name = document.createElement('small'); name.textContent = h.name + ' · delivered'; s.append(name); $('resultFriends').append(s); });
        $('nextMission').textContent = mission.id < 3 ? 'Next delivery →' : 'Back to our neighborhood →';
        setScreen('result');
        renderCards();
    }
    catch (e) {
        attention = true;
        receipt = null;
        failure('Finish delivery', e);
    }
    finally {
        busy = false;
        update();
    }
}
async function stopRobot() {
    if (!canHardware())
        throw new Error('Cannot send STOP while hidden or disconnected. Use the physical power switch if needed.');
    if (link.operation)
        throw new Error('Finish/cancel the device transfer first; STOP cannot preempt the host transfer lock.');
    pulseEpoch++;
    pulseWake?.();
    controlHint = '';
    lastInput = 'STOP requested; observe the real wheels.';
    run?.cancel();
    const expected = connectionKey(link.state);
    if (!gate || gateKey !== expected) {
        gate?.cancel();
        gate = newGate(expected);
    }
    try {
        const ok = await gate.stop();
        attention = !ok;
        if (!ok)
            throw new Error('STOP was not sent. Use the device power switch if it is moving.');
        runError = '';
        say('STOP sent — inspect the real wheels. No physical stop acknowledgement exists.');
        return true;
    }
    catch (e) {
        attention = true;
        receipt = null;
        failure('STOP — retry explicitly or use physical power', e);
        return false;
    }
    finally {
        update();
    }
}
async function leaveRun(adjust = false) {
    if (activeRun() && !adjust && !await ask('Finish this delivery?', 'Bolt will be asked to stop. Restart this route from the floor START marker next time.', 'Stop and leave'))
        return;
    const ok = await stopRobot();
    if (!ok)
        return;
    run = null;
    $('startReady').checked = false;
    setScreen('setup');
    if (adjust) {
        $('tuningPanel').setAttribute('open', '');
        $('testStatus').textContent = 'Great observing! Check forward/turn timing, upload any changes, then reset Bolt to START. Never correct a mismatch by assuming the map tracked it.';
    }
}
async function readDevice() {
    if (!link || busy || activeRun())
        throw new Error('Finish the delivery first.');
    busy = true;
    receipt = null;
    readCandidate = null;
    update();
    try {
        const data = await link.read();
        readCandidate = data.workspace;
        await store('parcel.v1.readback.raw', data.raw);
        await store('parcel.v1.readback.meta', metadata('device-readback'));
        let temp = null;
        try {
            parse(data.workspace);
            if (!blocksRegistered) {
                registerBlocks(B);
                blocksRegistered = true;
            }
            temp = new B.Workspace();
            B.serialization.workspaces.load(data.workspace, temp);
        }
        finally {
            temp?.dispose();
        }
        $('readInfo').textContent = `${data.bytes} bytes received through device notifications. These are editable route blocks, not downloaded Python. Replace your current route?`;
        $('readResult').classList.remove('hidden');
    }
    catch (e) {
        failure('Read blocks; current route kept', e);
        if (readCandidate)
            $('readInfo').textContent = 'Incompatible block set. Raw data retained; use the original module to edit it.';
    }
    finally {
        busy = false;
        update();
    }
}
async function replaceRead() {
    if (!readCandidate)
        return;
    if (!await ask('Use the recovered route?', 'Your current route will be backed up. The recovered blocks still need to be checked and uploaded for this mission.', 'Use recovered route'))
        return;
    parse(readCandidate);
    await backup('before-device-readback');
    loadWorkspace(clone(readCandidate));
    provenance = 'device-readback';
    $('codeLabel').textContent = 'Generated from recovered blocks — not device source';
    await saveDraft();
    $('readResult').classList.add('hidden');
    $('tools').classList.add('hidden');
    setScreen('build');
    await ensureEditors();
}
function onData(e) { if ($('showHex').checked)
    $('hex').textContent = e.data.slice(0, 180).map(x => x.toString(16).padStart(2, '0')).join(' '); }
function linkChanged() {
    if (!link || disposed)
        return;
    const k = connectionKey(link.state), a = link.state?.activity;
    const own = a?.owner.type === 'module' && (a.owner.id === context?.module.id || a.owner.id === context?.module.instanceId);
    if ((lastStateKey && k !== lastStateKey) || (a?.kind === 'upload' && !own)) {
        receipt = null;
        lightCheck = 'idle';
        lightReceipt = '';
        if (activeRun()) {
            run.cancel();
            attention = true;
        }
        say('The robot connection/program changed. Upload your route again.');
    }
    if (activeRun() && a && !own) {
        run.cancel();
        receipt = null;
        lightCheck = 'idle';
        lightReceipt = '';
        attention = true;
        say('Another client used the robot. The delivery ended; check Bolt and upload again.');
    }
    lastStateKey = k;
    update();
}
function visibilityChanged() {
    visible = hostVisible && !document.hidden;
    link?.setVisible(visible);
    if (!visible) {
        confirmAnswer?.(false);
        practice = false;
        if (activeRun() || busy || gate?.busy) {
            run?.cancel();
            gate?.cancel();
            pulseEpoch++;
            pulseWake?.();
            attention = true;
            receipt = null;
            lightCheck = 'idle';
            lightReceipt = '';
            status('The module was hidden. Check Bolt, send STOP on return, and upload again.');
        }
    }
    update();
}
function bind() {
    click('begin', () => selectMission(progress.selected));
    click('home', async () => { if (allowedUiChange()) {
        await saveDraft();
        setScreen('home');
        renderCards();
    } });
    click('briefBack', () => setScreen('home'));
    click('build', async () => { setScreen('build'); await ensureEditors(); });
    click('buildBack', () => setScreen('brief'));
    click('setupBack', async () => { setScreen('build'); await ensureEditors(); });
    click('save', async () => { if (await saveDraft())
        say('Your delivery route is saved.'); });
    click('check', () => checkNow());
    click('fitStudent', () => { resizeEditors(); student?.zoomToFit(); });
    click('fitExample', () => { resizeEditors(); sample?.zoomToFit(); });
    click('tabStudent', () => { $('workshop').dataset.tab = 'student'; $('tabStudent').classList.add('selected'); $('tabExample').classList.remove('selected'); resizeEditors(); });
    click('tabExample', () => { $('workshop').dataset.tab = 'example'; $('tabExample').classList.add('selected'); $('tabStudent').classList.remove('selected'); resizeEditors(); sample?.zoomToFit(); });
    click('reset', async () => { if (await ask('Make a fresh route?', 'We’ll keep a backup before clearing your route. Robot timing settings will stay.', 'Start fresh')) {
        await backup('before-reset');
        loadWorkspace(blank(currentTuning()));
        await saveDraft();
    } });
    click('copyExample', async () => { if (await ask('Use the finished example?', 'Try building it first. This rescue option backs up your work and records that you used a hint. You must still upload and drive the real route.', 'Use this example')) {
        await backup('before-example');
        const t = currentTuning();
        loadWorkspace(example(mission, t));
        progress.assisted[mission.id - 1] = true;
        if (progressWritable)
            await store('parcel.v1.progress', progress);
        await saveDraft();
    } });
    click('restoreBackup', async () => { const raw = await sdk?.storage.get('parcel.v1.backup'); if (!raw)
        throw new Error('No local backup yet.'); parse(raw); if (await ask('Restore your local backup?', 'This is saved local work, not a new device read.', 'Restore backup')) {
        loadWorkspace(raw);
        provenance = 'local-backup';
        await saveDraft();
    } });
    click('toSetup', async () => { checkNow(); if (assessment.ok) {
        await saveDraft();
        renderBoard($('setupBoard'), mission);
        fillTuning();
        $('startReady').checked = false;
        setScreen('setup');
    } });
    click('lightTest', testLight);
    click('lightYes', () => observeLight(true));
    click('lightNo', () => observeLight(false));
    click('practiceOpen', () => { if (!lightVerified() || busy || !$('floorReady').checked)
        return; practice = true; $('startReady').checked = false; update(); $('practicePanel').scrollIntoView({ block: 'center' }); $('practicePanel').focus({ preventScroll: true }); });
    click('practiceClose', () => { practice = false; update(); $('startReady').focus(); });
    for (const [id, act] of [['practiceForward', 'forward'], ['practiceLeft', 'left'], ['practiceRight', 'right']])
        click(id, () => testPulse(act));
    click('practiceStop', () => stopRobot());
    for (const [id, act] of [['routeForward', 'forward'], ['routeLeft', 'left'], ['routeRight', 'right'], ['routeStop', 'stop']])
        click(id, () => routeInput(act));
    click('returnSetup', () => leaveRun(true));
    click('connect', async () => { await link?.connect(); update(); });
    click('upload', upload);
    click('start', startRun);
    click('applyTuning', applyTuning);
    for (const [id, action] of [['testForward', 'forward'], ['testLeft', 'left'], ['testRight', 'right']])
        click(id, () => testPulse(action));
    listen($('floorReady'), 'change', () => update());
    listen($('startReady'), 'change', () => update());
    listen(document, 'keydown', keyboard);
    click('drive', drive);
    click('confirmStep', confirmStep);
    click('notThere', () => leaveRun(true));
    click('exitPlay', () => leaveRun());
    click('emergencyStop', () => stopRobot());
    click('toolStop', () => stopRobot());
    click('fullscreen', async () => { try {
        if (document.fullscreenElement === $('playScreen'))
            await document.exitFullscreen();
        else
            await $('playScreen').requestFullscreen();
    }
    catch (e) {
        say('Native fullscreen is unavailable; the delivery view still fills this module window.');
    } });
    click('nextMission', () => mission.id < 3 ? selectMission(mission.id + 1) : setScreen('home'));
    click('resultHome', () => { renderCards(); setScreen('home'); });
    click('noMovement', async () => { await leaveRun(true); lightCheck = 'failed'; lightReceipt = ''; $('testStatus').textContent = 'No movement reported. Recheck the light first. If the light works but wheels do not, check motor power/library and short-action settings with an adult.'; update(); });
    const openTools = async () => {
        if (document.fullscreenElement === $('playScreen'))
            await document.exitFullscreen();
        $('tools').classList.remove('hidden');
        $('toolsClose').focus();
    };
    click('toolsOpen', openTools);
    click('playToolsOpen', openTools);
    click('toolsClose', () => { $('tools').classList.add('hidden'); $(screen === 'play' ? 'playToolsOpen' : 'toolsOpen').focus(); });
    click('disconnect', async () => { await link?.disconnect(); receipt = null; gate = null; update(); });
    click('read', readDevice);
    click('replaceRead', replaceRead);
    click('keepRead', () => { $('readResult').classList.add('hidden'); readCandidate = null; });
    click('cancelRead', () => link?.cancelRead());
    click('cancelUpload', async () => { if (await ask('Cancel the device upload?', 'The host will disconnect the shared robot. Some blocks/code may already have changed. Cancellation is not rollback.', 'Cancel and disconnect'))
        await link?.cancelUpload(); });
    click('modalYes', () => confirmAnswer?.(true));
    click('modalNo', () => confirmAnswer?.(false));
    listen(document, 'keydown', ((e) => { if (!$('modal').classList.contains('hidden')) {
        if (e.key === 'Escape') {
            e.preventDefault();
            confirmAnswer?.(false);
        }
        if (e.key === 'Tab') {
            const first = $('modalNo'), last = $('modalYes');
            if (e.shiftKey && document.activeElement === first) {
                e.preventDefault();
                last.focus();
            }
            else if (!e.shiftKey && document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    } }));
    listen(document, 'visibilitychange', () => visibilityChanged());
    listen(window, 'pagehide', () => dispose());
}
function dispose() { if (disposed)
    return; disposed = true; visible = false; confirmAnswer?.(false); run?.cancel(); gate?.cancel(); if (saveTimer)
    clearTimeout(saveTimer); if (pulseTimer)
    clearTimeout(pulseTimer); pulseWake?.(); link?.dispose(); off.splice(0).forEach(fn => fn()); observers.splice(0).forEach(o => o.disconnect()); student?.dispose(); sample?.dispose(); }
async function init() {
    bind();
    paintMission();
    try {
        if (!window.icreator) {
            $('sdkWarning').textContent = 'Open this module in iCreator. You can explore the lessons here; real robot play and project saving need the host.';
            $('sdkWarning').classList.remove('hidden');
        }
        else {
            context = await window.icreator.ready();
            sdk = window.icreator;
            if (!context.capabilities?.device?.available) {
                $('sdkWarning').textContent = context.capabilities?.device?.unavailableReason ?? 'Bluetooth is unavailable in this host.';
                $('sdkWarning').classList.remove('hidden');
            }
            else {
                link = new Link(sdk, context, linkChanged, log, onData);
                try {
                    await link.init();
                }
                catch (e) {
                    link.dispose();
                    link = null;
                    throw e;
                }
            }
            const offVisible = sdk.lifecycle.onVisibilityChange(v => { hostVisible = v; visibilityChanged(); });
            if (offVisible)
                off.push(offVisible);
            const offDispose = sdk.lifecycle.onDispose(dispose);
            if (offDispose)
                off.push(offDispose);
            try {
                progress = readProgress(await sdk.storage.get('parcel.v1.progress'));
            }
            catch (e) {
                progressWritable = false;
                failure('Saved progress kept unchanged', e);
            }
        }
    }
    catch (e) {
        failure('Initialize iCreator', e);
        $('sdkWarning').textContent = 'iCreator initialization: ' + errorText(e) + '. Reopen the module to retry.';
        $('sdkWarning').classList.remove('hidden');
    }
    initialized = true;
    renderCards();
    if (progressWritable)
        status('Choose a delivery. Your real robot is the hero.');
    update();
    console.info(`[${MODULE_ID} ${VERSION}] ready; hardware actions require explicit input.`);
}
void init().catch(e => failure('Startup', e));
